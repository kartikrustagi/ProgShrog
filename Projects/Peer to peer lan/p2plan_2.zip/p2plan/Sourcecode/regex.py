#!/usr/bin/python

import re

def match_names(file_to_be_matched,file_without_ext):
	
	#We will first fetch each word and extension in file_without_ext
	w=re.split(' ',file_without_ext)
	
	#Now we will create the pattern/RE for matching
	p=' *'
	i=0
	
	while i<len(w):
		p+=(w[i]+'+ *')
		i=i+1
	
	#Now matching will be performed
	if re.search(p,file_to_be_matched,2)!=None:
		return 1
	else:
	      	return 0
	  
