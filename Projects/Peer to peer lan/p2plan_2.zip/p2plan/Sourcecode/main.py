#Copyright 2008 kartik rustagi
#
#This file is part of P2plan.
#
#    P2plan is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    P2plan is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with P2plan.  If not, see <http://www.gnu.org/licenses/>.


#!/usr/bin/python
import os
import socket
import string
import sys
import setip
import direc
import time

peers=[] 	#This list will hold addresses of all the nodes that are active on the Network
STATUS=0 	#This works like a Semaphore, avoiding data conflict
path='./files'  #This is the location of the folder where files to be shared are stored 
global ip	#This is the IP address of the system
Directory={}
Directory_index_selected=0

#These are the messages that are communicated to indicate the status of a node/user on the network
online='<pr1>I am online'        
reply="<pr2>I am online too"
close="<Close>I am going offline"


class main:
	
	def __init__(self):
		pass
	
	def update_peers(self,data1):  
		#This function is called to update peer nodes about its presence as well a to know which nodes are active.
		#This function updates the list data structure adding address of active nodes
		global STATUS          
		global peers
		z=string.find(data1,'<pr1>')
		if z!=-1:
			client.sendto(reply,addrs)
			peers.append(addrs)
                	prlength=len(peers)
			print peers," are online"
		elif z==-1:
			k=string.find(data1,'<pr2>')
			if k!=-1:
				peers.append(addrs)
				prlength=len(peers)
				print peers," are online"
		
		
	def initiate_find(self):
		#This function is initiated to initiate a file search operation by a node
		global STATUS
		global peers
		global path
		global Directory
		global Directory_index_selected
		print '-> Enter the file you want to find (Without Extensions).'
		self.strn=raw_input('->')
		self.strn='<srr>'+self.strn
		flag=0
		#A directory will be created which will hold file names matching the result along with the address of their respective hosts
		Directory_index=0
		for i in range(0,len(peers)):
			client.sendto(self.strn,peers[i])
			rep,addrs=client.recvfrom(1024)
			temp=rep.split('<srs>')
			#print 'Reply is ',rep
			#print 'Reply is from ',addrs
			rep=temp[1]
			if rep=='Yes':
				flag=1
				#Recieving name of files that succesfully matched from in this hosts directory
				suitable_files_string,addrs=client.recvfrom(1024)
				#print 'suitable_files_string is ',suitable_files_string
				suitable_files_list=suitable_files_string.split(' ')
				#print 'suitable_files_list is ',suitable_files_list
				#will add these files to the directory
				for j in range(0,len(suitable_files_list)):
					Directory_index=Directory_index+1
					#Each index stores file name and the host address in a List
					Directory[Directory_index]=[suitable_files_list[j],addrs]
								
			
		if flag==0:
			print '-> File not present in peers\'s directory.'
		else:
			print '-> Files matching Your results are :-'
			for s_no,file_name in Directory.items():
				print ' %d:%s'%(s_no,file_name[0])
			Directory_index_selected=raw_input('Enter the Serial number of file to be downloaded:')	 
			Directory_index_selected=int(Directory_index_selected)
			m.filerecieve(Directory[Directory_index_selected][1])
		
			
		
	def ifsearch(self,strn):
		# strn is the string that has to be searched
		# This function is called when ever the node recieves an incoming request to search 
		global STATUS
		global peers
		global path
		self.strn=strn
		#print '-> String to be searched is ',self.strn
		if STATUS==1:
			client.sendto('<srs>No',addrs)
			print '-> STATUS is busy, neglecting search request'
			pass
			
		STATUS=1
		os.system('pwd')
		os.chdir(path)
		ldir=os.listdir('./')
		flag=0
		lendir=len(ldir)
		import regex
		if(lendir!=0):
			appropriate_results=[] #This will store all the file names which are suitable match for the file being searched
			for i in range(0,lendir):
				#print 'ldir[i] is ',ldir[i]
				#print 'self.strn is ',self.strn
				#print 'i is ',i
				if regex.match_names(ldir[i],self.strn):
					flag=1
					#print 'File found'
					appropriate_results.append(ldir[i])
		
		if flag==1:
			client.sendto('<srs>Yes',addrs)
			#The list of appropriate results will be conversted to string of appropriate format
			#print 'appropriate_results is ',appropriate_results
			appropriate_results_string=str(appropriate_results)
			appropriate_results_string=appropriate_results_string.replace('[','')
			appropriate_results_string=appropriate_results_string.replace(']','')
			appropriate_results_string=appropriate_results_string.replace(',','')
			appropriate_results_string=appropriate_results_string.replace("'",'')
			#print 'appropriate_results_string is ',appropriate_results_string
			client.sendto(appropriate_results_string,addrs)
			
		if(lendir==0 or flag==0):
			#print '-> File not found'
			client.sendto('<srs>No',addrs)
		
		os.chdir('..')
		STATUS=0
				
				
	def filesend(self,strn):
	
		# This function is called when a file needs to be send from a node
		print '-> Sending file'
		global STATUS
		global peers
		STATUS=1
		
		
		self.strn=strn
		path='./files'
		fstr=path+'/'+self.strn
		f=file(fstr,'r')
		# Transfer of files is done via TCP for more reliability, error and flow control. Where as messaging system is done via UDP, it being 			connection less
		fssoc=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
		fssoc.bind((ip,2100))	
		data='<fssoc>'		
		client.sendto(data,addrs)		
		fssoc.listen(1)
		ptosend,atosend=fssoc.accept()
		fssoc.close()
		while 1:
			data=f.readline(5*1024) #Optimize buffer size to improve speed
			if data:
				ptosend.send(data)	
			if not data:	
				break
			
		time.sleep(.5)
		f.close()
		ptosend.close()
		STATUS=0
		print '-> File sent'
		print '\n'
		
	
	def filerecieve(self,addr):
		#This function is called when the nodes needs to recieve a file from another node
		print '-> Recieving file....'
		global STATUS
		global peers
		global Directory
		global Directory_index_selected
		#temp=self.strn.split('<srr>')
		#print 'Temp is ',temp
		#print 'Host Peer is', addr 
		os.chdir('./files')
		#temp2=self.strn.split('<srr>')
		#f=file(temp2[1],'w')
		#Opening file to write
		#print 'Directory[1] is ',Directory[1]
		f=file(Directory[Directory_index_selected][0],'w')
		frsoc=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
		frsoc.bind((ip,2100))
		client.sendto('<Begin>'+Directory[Directory_index_selected][0],addr)
		STATUS=1
		# Transfer of files is done via TCP for more reliability, error and flow control. Where as messaging system is done via UDP, it being 			#connection less 
		#Now the sender has openend a TCP port and is listning for connections
		#It will send '<fssoc>' to sender to start the process
		data,address=client.recvfrom(1024)
		if(string.find(data,'<fssoc>')==0):
			print '-> Connection being made to recieve file'
		frsoc.connect((addr[0],2100))		
		#connected to sender via TCP	
		
		while 1:
			data,address=frsoc.recvfrom(1024)
			if data:
				f.write(data)
			if not data:
				break
			
		
		print '-> File Recieved completely \n'
		f.close()
		frsoc.close()
		STATUS=0
		os.chdir('..')
		Directory={}


			
		
m=main()
#This socket is use for the messaging system
client=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)

import detectip 	#To detect users IP address
f=file('./userip','r')	#This file stores the IP address
ip=f.readline()
f.close()

client.bind((ip,2000))	
port=client.getsockname()	#Socket address of the UDP socket, binded at port 2000

f=file('./iprange','r')	#This file stores the network subnet
s=f.readline()
f.close()

for i in range(1,255): #Sending message to all the nodes in subnet indicating the presence of this node
	ladr=((string.replace(s,'x','%d'%i)),2000)
	if ladr==port:
        	continue
	client.sendto(online,ladr)
	
while 1:  #This is the main loop which controls the flow of the function
	try:
		print '-> Press cntrl+c (KeyBoard Interrup) to initiate Search for file operation or to close the application'
		data1,addrs=client.recvfrom(1024)
		
		if(string.find(data1,'<pr1>')==0 or string.find(data1,'<pr2>')==0):
			m.update_peers(data1)
		elif(string.find(data1,'<srr>')==0):
			l=data1.split('<srr>')
			m.ifsearch(l[1])	
		elif(string.find(data1,'<Begin>')==0):
			temp=data1.split('<Begin>')
			m.filesend(temp[1])
		elif(string.find(data1,'<Close>')==0):
			peers.remove(addrs)
			print peers," are online"
				
		
		
	except KeyboardInterrupt:
		STATUS=1
		print 'Enter the operation you want to do.'
		print '1.Search \n2.Close Connection \n'
		data1=raw_input()
		if data1=='1':
			m.initiate_find()
		elif data1=='2':
			for i in range(0,len(peers)):
				client.sendto(close,peers[i])
			client.close()
			sys.exit()
					
			
		
