#Copyright 2008 kartik rustagi
#
#This file is part of P2plan.
#
#    P2plan is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    P2plan is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with P2plan.  If not, see <http://www.gnu.org/licenses/>.



#!/usr/bin/python
#This script let the user select network subnet

import os

ldir=os.listdir('./')
flag=0
lendir=len(ldir)
if(lendir!=0):
	for i in range(0,lendir):
		if ldir[i]=='iprange':
			flag=1
			print 'IP range already set'
			print 'Do you want to reset it?(y/n)'
			s=raw_input()
			if s=='y':
				flag=0
			break
		
if(lendir==0 or flag==0):
	f=file('./iprange','w')
	print 'This file contains the subnet of IP addresses which user using this p-2-p client will have. For example if users have IP addresses of the type 192.168.1.x where x can vary from 0 to 255 then the subnet will be 192.168.1.x . Remember to have x at only the last position of the subnet like 192.168.1.x or like 10.1.1.x or 10.23.12.x'
	print 'Enter subnet' 
	s=raw_input()
	f.write(s)
	f.close()
	print 'File created at:'
	os.system('pwd')




