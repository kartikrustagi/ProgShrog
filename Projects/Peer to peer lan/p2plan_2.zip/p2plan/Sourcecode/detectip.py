#Copyright 2008 kartik rustagi
#
#This file is part of P2plan.
#
#    P2plan is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    P2plan is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with P2plan.  If not, see <http://www.gnu.org/licenses/>.


#!/use/bin/python
#This script detects the IP address of the system by fetching it from unix commant 'ifconfig'

import os
import re
import string

f=file('./iprange','r')
s=f.readline()
f.close()
pattern='inet addr:'+s
pattern=string.split(pattern,'x')[0]
pattern='('+pattern+'...'+')'

os.system('ifconfig -a >> interfaces')
f=file('./interfaces','r')
s=f.readline()

while (len(s))!=0:
	i=re.search(pattern,s)
	if i!=None:
		sp=re.split(pattern,s)[1]
		ip=re.split('inet addr:',sp)[1]
		break
	s=f.readline()

f.close()
os.system('rm ./interfaces')
f=file('./userip','w')
f.write(ip)
f.close()



		
